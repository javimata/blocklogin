<?php
/**
 * @package     Joomla.Plugin
 * @subpackage  Content.Fbsocial
 *
 * @copyright   Copyright (C) 2005 - 2017 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die();


class PlgSystemBlocklogin extends JPlugin
{

	public function onBeforeRender()
  	{

  		// Check if are in the admin section and skip else continue
		$app  = JFactory::getApplication();

        if ($app->isClient('administrator'))
		{
			return;
        }

        if ( JRequest::getVar('option') == "com_users") {

            $redirect   = $this->params->get('redirect','/');

            header('Location: ' . $redirect);
            
        };

    }

}
